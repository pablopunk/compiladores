
# Para compilar y ejecutar podemos usar el makefile
# simplemente tecleamos "make" o "make linux" o "make osx"
# y se genera el ejecutable "compilador"
# Para ejecutar este debemos pasarle el archivo como argumento
# o irlo tecleando en tiempo de ejecucion:

make && ./compilador entrada.txt

## Tambien se puede convertir este README en script y ejecutarlo
